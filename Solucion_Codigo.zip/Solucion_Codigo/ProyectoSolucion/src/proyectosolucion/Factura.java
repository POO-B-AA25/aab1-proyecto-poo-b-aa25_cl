package proyectosolucion;
import java.util.ArrayList;

public class Factura {
    private Cliente cliente;
    private ArrayList<Producto> productos;
    private double total;
    private double subtotal;
    private int contadorFacturas;

    public Factura(Cliente cliente, ArrayList<Producto> productos) {
        this.cliente = cliente;
        this.productos = productos;
    }

    public double calcularTotal() {
        total = 0.0;
        for (Producto p : productos) {
            total += p.getPrecioFinal();
        }
        return total;
    }
}
